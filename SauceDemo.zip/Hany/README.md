# 🚀 SauceDemo Automation Testing Project

**By:** Hany Said Abokhadiga
**Email:** saidhany235@gmail.com
**Date:** November 25, 2025
**Status:** ✅ Complete \& Ready to Use

***

## 📋 Project Overview

This is a comprehensive **Selenium + Java** automation testing project for **SauceDemo.com**. The project implements **19 Test Cases** (13 Positive + 6 Negative) using the **Page Object Model (POM)** design pattern and **TestNG** framework.

### 🎯 Project Objectives

- ✅ Automate end-to-end testing of SauceDemo e-commerce website
- ✅ Implement best practices: POM, ISTQB standards, boundary value analysis
- ✅ Create comprehensive test coverage for Login, Products, Cart, and Checkout flows
- ✅ Document all test cases with clear step-by-step procedures

***

## 📊 Test Statistics

| Test Suite | Positive | Negative | Total |
| :-- | :-- | :-- | :-- |
| **LoginTest** | 1 | 3 | **4** |
| **ProductTest** | 5 | 1 | **6** |
| **CartTest** | 3 | 0 | **3** |
| **CheckOutTest** | 3 | 3 | **6** |
| **TOTAL** | **13** | **6** | **19** |


***

## 🏗️ Project Structure

```
saucedemo-automation/
├── src/
│   ├── main/java/Pages/
│   │   ├── LoginPage.java
│   │   ├── ProductPage.java
│   │   ├── CartPage.java
│   │   └── CheckOutPage.java
│   ├── test/java/Tests/
│   │   ├── LoginTest.java
│   │   ├── ProductTest.java
│   │   ├── CartTest.java
│   │   └── CheckOutTest.java
│   └── resources/testng.xml
├── pom.xml
├── README.md
└── .gitignore
```


***

## 🛠️ Technologies \& Tools

| Technology | Version | Purpose |
| :-- | :-- | :-- |
| **Java** | 11+ | Programming Language |
| **Selenium WebDriver** | 4.15.0 | Browser Automation |
| **TestNG** | 7.8.1 | Test Framework |
| **Maven** | 3.8+ | Build Management |
| **Edge Browser** | Latest | Test Browser |
| **Git** | Latest | Version Control |


***

## 🔗 Author \& Contact

- Project Author: Hany Said Abokhadiga
- Email: saidhany235@gmail.com
- GitHub: [https://github.com/hanysa3id](https://github.com/hanysa3id)
- LinkedIn: [https://www.linkedin.com/in/hany-said-abokhadiga-146690159/](https://www.linkedin.com/in/hany-said-abokhadiga-146690159/)

***
Happy Testing! 🚀

