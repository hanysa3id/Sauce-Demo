package Tests;

import Pages.CartPage;
import Pages.LoginPage;
import Pages.ProductPage;
import Utils.DriverManager;
import io.qameta.allure.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

@Epic("SauceDemo")
@Feature("Cart")
@Owner("Hany Said Abokhadiga")
public class CartTest {

    WebDriver driver;
    CartPage cartPage;
    ProductPage productPage;
    LoginPage loginPage;

    @BeforeMethod
    public void setUp() {
        driver = new EdgeDriver();
        DriverManager.setDriver(driver);
        driver.get("https://www.saucedemo.com/");

        cartPage = new CartPage(driver);
        productPage = new ProductPage(driver);
        loginPage = new LoginPage(driver);

        loginPage
                .enterEmailAndPassword("standard_user", "secret_sauce")
                .verifyLoginSuccess();
        productPage.verifyInventoryPageLoaded();
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test(description = "TC001: Verify Removing Product from Cart", priority = 1)
    @Story("Remove product from cart")
    @Description("Verify that a product added to the cart can be removed successfully and the cart becomes empty.")
    @Severity(SeverityLevel.CRITICAL)
    public void verifyRemovingProductTC() {

        productPage
                .clearCartCounter()
                .addProductToCart("Sauce Labs Backpack")
                .verifyAddedProduct();

        driver.get("https://www.saucedemo.com/cart.html");

        cartPage
                .verifyCartPageLoaded()
                .verifyProductsInCart();

        int itemsBeforeRemoval = cartPage.getCartItemCount();
        Assert.assertTrue(itemsBeforeRemoval >= 1, "Expected at least 1 item in cart before removal");

        cartPage
                .removeProductFromCart("Sauce Labs Backpack")
                .verifyProductRemoved("Sauce Labs Backpack")
                .verifyCartBadgeUpdated(0)
                .verifyCartIsEmpty();
    }

    @Test(description = "TC002: Verify Navigation from Cart to Products Page", priority = 2)
    @Story("Navigate from cart to products page")
    @Description("Verify that user can navigate back to the products page from the cart using the Continue Shopping button.")
    @Severity(SeverityLevel.NORMAL)
    public void verifyNavigationToProductPageTC() {

        productPage
                .clearCartCounter()
                .addProductToCart("Sauce Labs Bike Light")
                .verifyAddedProduct();

        driver.get("https://www.saucedemo.com/cart.html");

        cartPage
                .verifyCartPageLoaded();

        int itemsInCart = cartPage.getCartItemCount();
        Assert.assertEquals(itemsInCart, 1, "Expected 1 item in cart");

        cartPage
                .clickContinueShoppingButton()
                .verifyNavigationToProductsPage();

        productPage.verifyInventoryPageLoaded();
    }

    @Test(description = "TC003: Verify Navigation from Cart to Checkout Page", priority = 3)
    @Story("Navigate from cart to checkout")
    @Description("Verify that user can proceed from the cart page to the checkout page with multiple products in the cart.")
    @Severity(SeverityLevel.CRITICAL)
    public void verifyNavigationToCheckoutPageTC() {

        productPage
                .clearCartCounter()
                .addProductToCart("Sauce Labs Backpack")
                .addProductToCart("Sauce Labs Bike Light")
                .verifyAddedProduct();

        driver.get("https://www.saucedemo.com/cart.html");

        cartPage
                .verifyCartPageLoaded();

        int itemsInCart = cartPage.getCartItemCount();
        Assert.assertEquals(itemsInCart, 2, "Expected 2 items in cart");

        java.util.List<String> cartProducts = cartPage.getProductNamesInCart();
        Assert.assertTrue(cartProducts.contains("Sauce Labs Backpack"));
        Assert.assertTrue(cartProducts.contains("Sauce Labs Bike Light"));

        cartPage
                .clickCheckoutButton()
                .verifyNavigationToCheckoutPage();
    }
}
