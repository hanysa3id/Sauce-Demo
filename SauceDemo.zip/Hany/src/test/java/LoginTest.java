package Tests;

import CustomListeners.TestNGListeners;
import Pages.LoginPage;
import Utils.DriverManager;
import io.qameta.allure.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.*;

@Listeners(TestNGListeners.class)
@Epic("SauceDemo")
@Feature("Login")
@Owner("Hany Said Abokhadiga")
public class LoginTest {

    WebDriver driver;
    LoginPage loginPage;

    @BeforeMethod
    public void setUp() {
        driver = new EdgeDriver();
        DriverManager.setDriver(driver);
        driver.get("https://www.saucedemo.com/");
        loginPage = new LoginPage(driver);
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test(description = "TC001: Verify Login with Valid Email and Valid Password", priority = 1)
    @Story("Successful login with valid standard_user credentials")
    @Description("Verify that a user can log in successfully using valid username 'standard_user' and password 'secret_sauce'.")
    @Severity(SeverityLevel.CRITICAL)
    public void verifyLoginWithValidDataTC() {
        loginPage
                .verifyLoginPageElements()
                .enterEmailAndPassword("standard_user", "secret_sauce")
                .verifyLoginSuccess();
    }

    @Test(description = "TC002: Verify Login with Valid Email and Invalid Password", priority = 2)
    @Story("Login failure with invalid password")
    @Description("Verify that login fails and an error message is shown when using a valid username 'standard_user' with an invalid password.")
    @Severity(SeverityLevel.CRITICAL)
    public void verifyLoginWithValidEmailAndInvalidPass() {
        loginPage
                .verifyLoginPageElements()
                .enterEmailAndPassword("standard_user", "wrong_password")
                .verifyErrorMessageAppears("Username and password do not match any user")
                .verifyLoginFailed();
    }

    @Test(description = "TC003: Verify Login with Invalid Email and Valid Password", priority = 3)
    @Story("Login failure with invalid username")
    @Description("Verify that login fails and an error message is shown when using an invalid username with a valid password 'secret_sauce'.")
    @Severity(SeverityLevel.CRITICAL)
    public void verifyLoginWithInValidEmailAndValidPass() {
        loginPage
                .verifyLoginPageElements()
                .enterEmailAndPassword("invalid_user@test.com", "secret_sauce")
                .verifyErrorMessageAppears("Username and password do not match any user")
                .verifyLoginFailed();
    }

    @Test(description = "TC004: Verify Login with Empty Email and Password Fields", priority = 4)
    @Story("Login failure with empty credentials")
    @Description("Verify that login fails and 'Username is required' message appears when both username and password fields are left empty.")
    @Severity(SeverityLevel.NORMAL)
    public void verifyLoginWithEmptyFields() {
        loginPage
                .verifyLoginPageElements()
                .verifyFieldsAreEmpty()
                .clickLoginButtonWithEmptyFields()
                .verifyErrorMessageAppears("Username is required")
                .verifyLoginFailed();
    }
}
