package Tests;

import Pages.LoginPage;
import Pages.ProductPage;
import Utils.DriverManager;
import io.qameta.allure.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.*;

@Epic("SauceDemo")
@Feature("Products")
@Owner("Hany Said Abokhadiga")
public class ProductTest {

    WebDriver driver;
    ProductPage productPage;
    LoginPage loginPage;

    @BeforeMethod
    public void setUp() {
        driver = new EdgeDriver();
        DriverManager.setDriver(driver);
        driver.get("https://www.saucedemo.com/");
        productPage = new ProductPage(driver);
        loginPage = new LoginPage(driver);

        loginPage
                .enterEmailAndPassword("standard_user", "secret_sauce")
                .verifyLoginSuccess();
        productPage.verifyInventoryPageLoaded();
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test(description = "TC001: Verify Product is Added to Cart", priority = 1)
    @Story("Add product to cart")
    @Description("Verify that a single product (Sauce Labs Backpack) can be added to the cart and reflected in the cart badge.")
    @Severity(SeverityLevel.CRITICAL)
    public void verifyAddToCartTC() {
        productPage
                .clearCartCounter()
                .addProductToCart("Sauce Labs Backpack")
                .verifyAddedProduct();
    }

    @Test(description = "TC002: Verify All Products Images are Displayed", priority = 2)
    @Story("View product images")
    @Description("Verify that all products displayed on the inventory page have visible images with valid src attributes.")
    @Severity(SeverityLevel.NORMAL)
    public void verifyProductsImageIsDisplayedTC() {
        int productCount = productPage.getProductCount();
        org.testng.Assert.assertTrue(productCount > 0, "No products found on inventory page");
        productPage.verifyProductsImageIsDisplayed();
    }

    @Test(description = "TC003: Verify All Products Prices are Displayed", priority = 3)
    @Story("View product prices")
    @Description("Verify that all products have visible prices and each price is formatted with a currency symbol.")
    @Severity(SeverityLevel.NORMAL)
    public void verifyProductsPriceIsDisplayedTC() {
        int productCount = productPage.getProductCount();
        org.testng.Assert.assertTrue(productCount > 0, "No products found on inventory page");
        productPage.verifyProductsPriceIsDisplayed();
    }

    @Test(description = "TC004: Verify All Products Descriptions are Displayed", priority = 4)
    @Story("View product descriptions")
    @Description("Verify that all products on the inventory page have non-empty descriptions displayed.")
    @Severity(SeverityLevel.NORMAL)
    public void verifyProductsDescriptionIsDisplayedTC() {
        int productCount = productPage.getProductCount();
        org.testng.Assert.assertTrue(productCount > 0, "No products found on inventory page");
        productPage.verifyProductsDescriptionIsDisplayed();
    }

    @Test(description = "TC005: Verify Product Sorting (A-Z)", priority = 5)
    @Story("Sort products alphabetically")
    @Description("Verify that sorting products by Name (A to Z) orders the inventory list alphabetically without changing product count.")
    @Severity(SeverityLevel.NORMAL)
    public void verifySortingTC() {
        int productCountBefore = productPage.getProductCount();
        org.testng.Assert.assertTrue(productCountBefore > 0, "No products found on inventory page");
        productPage.verifySortingTC();
        int productCountAfter = productPage.getProductCount();
        org.testng.Assert.assertEquals(productCountBefore, productCountAfter, "Product count changed after sorting");
    }

    @Test(description = "TC006: Verify Product Prices Valid Range (Not Negative/Zero)", priority = 6)
    @Story("Validate product price range")
    @Description("Verify that all product prices are within a valid range: greater than zero and less than 1000.")
    @Severity(SeverityLevel.CRITICAL)
    public void verifyProductPriceValidRangeTC() {
        productPage.verifyInventoryPageLoaded();
        java.util.List<WebElement> prices = driver.findElements(
                org.openqa.selenium.By.cssSelector("[class=\"inventory_item_price\"]")
        );

        org.testng.Assert.assertTrue(prices.size() > 0, "No products found!");

        for (WebElement price : prices) {
            String priceText = price.getText().trim();
            double priceValue = Double.parseDouble(
                    priceText.replaceAll("[^0-9.]", "")
            );

            org.testng.Assert.assertTrue(priceValue > 0,
                    "Invalid price found: " + priceValue);

            org.testng.Assert.assertTrue(priceValue < 1000,
                    "Price seems unrealistic: " + priceValue);
        }
    }
}
