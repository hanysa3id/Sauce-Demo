package Tests;

import Pages.CartPage;
import Pages.CheckOutPage;
import Pages.LoginPage;
import Pages.ProductPage;
import Utils.DriverManager;
import io.qameta.allure.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

@Epic("SauceDemo")
@Feature("Checkout")
@Owner("Hany Said Abokhadiga")
public class CheckOutTest {

    WebDriver driver;
    CheckOutPage checkoutPage;
    CartPage cartPage;
    ProductPage productPage;
    LoginPage loginPage;

    @BeforeMethod
    public void setUp() {
        driver = new EdgeDriver();
        DriverManager.setDriver(driver);
        driver.get("https://www.saucedemo.com/");

        checkoutPage = new CheckOutPage(driver);
        cartPage = new CartPage(driver);
        productPage = new ProductPage(driver);
        loginPage = new LoginPage(driver);

        loginPage
                .enterEmailAndPassword("standard_user", "secret_sauce")
                .verifyLoginSuccess();
        productPage.verifyInventoryPageLoaded();
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test(description = "E2E: Complete purchase flow from login to order confirmation", priority = 7)
    @Story("End-to-end purchase journey")
    @Description("Login, add products to cart, proceed to checkout, fill customer data, verify totals, and confirm successful order.")
    @Severity(SeverityLevel.CRITICAL)
    public void verifyEndToEndPurchaseFlowTC() {

        productPage
                .clearCartCounter()
                .addProductToCart("Sauce Labs Backpack")
                .addProductToCart("Sauce Labs Bike Light")
                .verifyAddedProduct();

        driver.get("https://www.saucedemo.com/cart.html");

        cartPage
                .verifyCartPageLoaded()
                .verifyProductsInCart()
                .clickCheckoutButton()
                .verifyNavigationToCheckoutPage();

        checkoutPage
                .verifyFormFieldsDisplayed()
                .fillCheckoutForm("Hany", "Ahmed", "12345")
                .clickContinueButton()
                .verifyNavigationToOverviewPage()
                .verifyTotalAmountCalculation()
                .clickFinishButton()
                .verifyCheckoutComplete();

    }

    @Test(description = "TC001: Verify Checkout with All Fields Filled", priority = 1)
    @Story("Successful checkout with valid customer data")
    @Description("Verify that user can complete checkout step one when all required fields are filled with valid data.")
    @Severity(SeverityLevel.CRITICAL)
    public void verifyFillAllFieldsTC() {

        productPage
                .clearCartCounter()
                .addProductToCart("Sauce Labs Backpack")
                .addProductToCart("Sauce Labs Bike Light")
                .verifyAddedProduct();

        driver.get("https://www.saucedemo.com/cart.html");

        cartPage
                .verifyCartPageLoaded();

        int itemsInCart = cartPage.getCartItemCount();
        Assert.assertTrue(itemsInCart >= 1, "Expected at least one item in cart");

        cartPage
                .clickCheckoutButton()
                .verifyNavigationToCheckoutPage();

        checkoutPage
                .verifyFormFieldsDisplayed()
                .fillCheckoutForm("Hany", "Ahmed", "12345")
                .clickContinueButton()
                .verifyNavigationToOverviewPage();
    }

    @Test(description = "TC002: Verify Error Message with Empty Fields", priority = 2)
    @Story("Checkout validation for empty customer data")
    @Description("Verify that an error message is displayed when user tries to continue checkout with all fields empty.")
    @Severity(SeverityLevel.CRITICAL)
    public void verifyEmptyFieldsTC() {

        productPage
                .clearCartCounter()
                .addProductToCart("Sauce Labs Onesie")
                .verifyAddedProduct();

        driver.get("https://www.saucedemo.com/cart.html");

        cartPage
                .verifyCartPageLoaded()
                .clickCheckoutButton();

        checkoutPage
                .verifyFormFieldsDisplayed()
                .verifyEmptyFieldsError();
    }

    @Test(description = "TC003: Verify Error Message with One Empty Field", priority = 3)
    @Story("Checkout validation for partially filled form")
    @Description("Verify that an appropriate error message is displayed when one of the required fields is left empty.")
    @Severity(SeverityLevel.CRITICAL)
    public void verifyOneEmptyFieldTC() {

        productPage
                .clearCartCounter()
                .addProductToCart("Sauce Labs Backpack")
                .verifyAddedProduct();

        driver.get("https://www.saucedemo.com/cart.html");

        cartPage
                .verifyCartPageLoaded()
                .clickCheckoutButton();

        checkoutPage
                .verifyFormFieldsDisplayed()
                .verifyOneEmptyFieldError("firstname");
    }

    @Test(description = "TC004: Verify Total Amount Calculation", priority = 4)
    @Story("Verify checkout total calculation")
    @Description("Verify that the total amount on the overview page is correctly calculated as subtotal plus tax.")
    @Severity(SeverityLevel.CRITICAL)
    public void verifyTotalAmountTC() {

        productPage
                .clearCartCounter()
                .addProductToCart("Sauce Labs Backpack")
                .addProductToCart("Sauce Labs Bolt T-Shirt")
                .verifyAddedProduct();

        driver.get("https://www.saucedemo.com/cart.html");

        cartPage
                .verifyCartPageLoaded()
                .clickCheckoutButton();

        checkoutPage
                .fillCheckoutForm("Hany", "Ahmed", "12345")
                .clickContinueButton()
                .verifyNavigationToOverviewPage()
                .verifyTotalAmountCalculation();
    }

    @Test(description = "TC005: Verify Checkout Complete", priority = 5)
    @Story("Complete checkout flow")
    @Description("Verify that user can complete the full checkout flow from cart to confirmation page and see the success message.")
    @Severity(SeverityLevel.CRITICAL)
    public void verifyCheckOutCompleteTC() {

        productPage
                .clearCartCounter()
                .addProductToCart("Sauce Labs Backpack")
                .addProductToCart("Sauce Labs Bike Light")
                .addProductToCart("Sauce Labs Bolt T-Shirt")
                .verifyAddedProduct();

        driver.get("https://www.saucedemo.com/cart.html");

        cartPage
                .verifyCartPageLoaded()
                .clickCheckoutButton();

        checkoutPage
                .fillCheckoutForm("Hany", "Ahmed", "12345")
                .clickContinueButton()
                .verifyNavigationToOverviewPage();

        int itemsOnOverview = checkoutPage.getCartItemsCount();
        Assert.assertTrue(itemsOnOverview >= 1, "Expected items to be listed on overview page");

        checkoutPage
                .verifyTotalAmountCalculation()
                .clickFinishButton()
                .verifyCheckoutComplete();

        Assert.assertTrue(
                driver.findElements(org.openqa.selenium.By.id("back-to-products")).size() > 0,
                "Back to home button not found"
        );
    }

    @Test(description = "TC006: Verify Invalid Postal Code Validation", priority = 6)
    @Story("Checkout with invalid postal code")
    @Description("Verify system behaviour when an invalid postal code containing letters is used during checkout.")
    @Severity(SeverityLevel.NORMAL)
    public void verifyInvalidPostalCodeTC() {

        productPage
                .clearCartCounter()
                .addProductToCart("Sauce Labs Backpack")
                .verifyAddedProduct();

        driver.get("https://www.saucedemo.com/cart.html");

        cartPage
                .verifyCartPageLoaded()
                .clickCheckoutButton();

        checkoutPage
                .verifyFormFieldsDisplayed()
                .clearFormFields();

        driver.findElement(org.openqa.selenium.By.id("first-name")).sendKeys("Hany");
        driver.findElement(org.openqa.selenium.By.id("last-name")).sendKeys("Ahmed");
        driver.findElement(org.openqa.selenium.By.id("postal-code")).sendKeys("ABCDE");
        driver.findElement(org.openqa.selenium.By.id("continue")).click();

        try {
            Thread.sleep(500);
            String currentUrl = driver.getCurrentUrl();

            if (currentUrl.contains("checkout-step-one")) {
                Assert.assertTrue(true, "Invalid postal code was correctly rejected");
            } else if (currentUrl.contains("checkout-step-two")) {
                Assert.assertTrue(true, "Application accepted non-numeric postal code (documented behaviour)");
            } else {
                Assert.fail("Unexpected navigation after submitting invalid postal code: " + currentUrl);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
