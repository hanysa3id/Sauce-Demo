package Pages;

import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import java.util.List;

public class CheckOutPage {

    private final WebDriver driver;

    public CheckOutPage(WebDriver driver) {
        this.driver = driver;
    }

    private final By firstNameField   = By.id("first-name");
    private final By lastNameField    = By.id("last-name");
    private final By postalCodeField  = By.id("postal-code");
    private final By continueButton   = By.id("continue");
    private final By cancelButton     = By.id("cancel");

    private final By finishButton     = By.id("finish");
    private final By summaryTotal     = By.cssSelector("[class=\"summary_total_label\"]");
    private final By summarySubtotal  = By.cssSelector("[class=\"summary_subtotal_label\"]");
    private final By summaryTax       = By.cssSelector("[class=\"summary_tax_label\"]");

    private final By completeHeader   = By.cssSelector("[class=\"complete-header\"]");
    private final By completeMessage  = By.cssSelector("[class=\"complete-text\"]");
    private final By backHomeButton   = By.id("back-to-products");

    private final By errorMessage     = By.xpath("//h3[@data-test='error']");
    private final By cartItems        = By.cssSelector("[class=\"cart_item\"]");

    @Step("Fill checkout form with firstName={firstName}, lastName={lastName}, postalCode={postalCode}")
    public CheckOutPage fillCheckoutForm(String firstName, String lastName, String postalCode) {
        try {
            Thread.sleep(300);
            Assert.assertTrue(
                    driver.findElement(firstNameField).isDisplayed(),
                    "First Name field not displayed!"
            );
            driver.findElement(firstNameField).sendKeys(firstName);
            driver.findElement(lastNameField).sendKeys(lastName);
            driver.findElement(postalCodeField).sendKeys(postalCode);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Click Continue button on checkout form")
    public CheckOutPage clickContinueButton() {
        try {
            Thread.sleep(300);
            driver.findElement(continueButton).click();
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify navigation to checkout overview page")
    public CheckOutPage verifyNavigationToOverviewPage() {
        try {
            Thread.sleep(500);
            String currentUrl = driver.getCurrentUrl();
            Assert.assertTrue(
                    currentUrl.contains("checkout-step-two"),
                    "Not on overview page! URL: " + currentUrl
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify error message when all checkout fields are empty")
    public CheckOutPage verifyEmptyFieldsError() {
        try {
            Thread.sleep(300);
            driver.findElement(continueButton).click();
            Thread.sleep(300);
            Assert.assertTrue(
                    driver.findElements(errorMessage).size() > 0,
                    "Error message not displayed!"
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify error message when fieldType={fieldType} is left empty")
    public CheckOutPage verifyOneEmptyFieldError(String fieldType) {
        try {
            Thread.sleep(300);
            switch (fieldType.toLowerCase()) {
                case "firstname":
                    driver.findElement(lastNameField).sendKeys("Test");
                    driver.findElement(postalCodeField).sendKeys("12345");
                    break;
                case "lastname":
                    driver.findElement(firstNameField).sendKeys("Test");
                    driver.findElement(postalCodeField).sendKeys("12345");
                    break;
                case "postalcode":
                    driver.findElement(firstNameField).sendKeys("Test");
                    driver.findElement(lastNameField).sendKeys("Test");
                    break;
                default:
                    throw new IllegalArgumentException("Unsupported field type: " + fieldType);
            }
            driver.findElement(continueButton).click();
            Thread.sleep(300);
            Assert.assertTrue(
                    driver.findElements(errorMessage).size() > 0,
                    "Error message not displayed for empty " + fieldType + "!"
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify total amount calculation on overview page")
    public CheckOutPage verifyTotalAmountCalculation() {
        try {
            Thread.sleep(500);
            String subtotalText = driver.findElement(summarySubtotal).getText();
            String taxText      = driver.findElement(summaryTax).getText();
            String totalText    = driver.findElement(summaryTotal).getText();

            double subtotal = extractPrice(subtotalText);
            double tax      = extractPrice(taxText);
            double total    = extractPrice(totalText);

            double expectedTotal = subtotal + tax;

            Assert.assertEquals(
                    total,
                    expectedTotal,
                    0.01,
                    "Total calculation is incorrect! Expected: " + expectedTotal + " | Actual: " + total
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Click Finish button on overview page")
    public CheckOutPage clickFinishButton() {
        try {
            Thread.sleep(300);
            driver.findElement(finishButton).click();
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify checkout complete page is displayed")
    public CheckOutPage verifyCheckoutComplete() {
        try {
            Thread.sleep(500);
            String currentUrl = driver.getCurrentUrl();
            Assert.assertTrue(
                    currentUrl.contains("checkout-complete"),
                    "Not on complete page! URL: " + currentUrl
            );
            Assert.assertTrue(
                    driver.findElements(completeHeader).size() > 0,
                    "Complete header not found!"
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Click Back to Home button on checkout complete page")
    public CheckOutPage clickBackToHomeButton() {
        try {
            Thread.sleep(300);
            driver.findElement(backHomeButton).click();
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    private double extractPrice(String text) {
        return Double.parseDouble(text.replaceAll("[^0-9.]", ""));
    }

    @Step("Clear checkout form fields")
    public CheckOutPage clearFormFields() {
        driver.findElement(firstNameField).clear();
        driver.findElement(lastNameField).clear();
        driver.findElement(postalCodeField).clear();
        return this;
    }

    @Step("Verify checkout form fields are displayed")
    public CheckOutPage verifyFormFieldsDisplayed() {
        try {
            Thread.sleep(300);
            Assert.assertTrue(
                    driver.findElement(firstNameField).isDisplayed(),
                    "First Name field not displayed"
            );
            Assert.assertTrue(
                    driver.findElement(lastNameField).isDisplayed(),
                    "Last Name field not displayed"
            );
            Assert.assertTrue(
                    driver.findElement(postalCodeField).isDisplayed(),
                    "Postal Code field not displayed"
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Get number of items displayed in checkout cart")
    public int getCartItemsCount() {
        List<?> items = driver.findElements(cartItems);
        return items.size();
    }
}
