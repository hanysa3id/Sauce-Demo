package Pages;

import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class CartPage {

    private final WebDriver driver;

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    private final By cartItems             = By.cssSelector("[class=\"cart_item\"]");
    private final By cartItemNames         = By.cssSelector("[class=\"inventory_item_name\"]");
    private final By cartItemPrices        = By.cssSelector("[class=\"inventory_item_price\"]");
    private final By removeButtons         = By.cssSelector("button.cart_button");
    private final By cartBadge             = By.cssSelector("[class=\"shopping_cart_badge\"]");
    private final By continueShoppingButton = By.id("continue-shopping");
    private final By checkoutButton         = By.id("checkout");
    private final By cartContainer          = By.cssSelector("[class=\"cart_list\"]");
    private final By quantityLabels         = By.cssSelector("[class=\"cart_quantity\"]");

    @Step("Verify cart page is loaded")
    public CartPage verifyCartPageLoaded() {
        try {
            Thread.sleep(500);
            Assert.assertTrue(
                    driver.findElements(cartContainer).size() > 0,
                    "Cart page not loaded!"
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify products exist in cart")
    public CartPage verifyProductsInCart() {
        try {
            Thread.sleep(500);
            List<WebElement> items = driver.findElements(cartItems);
            Assert.assertTrue(items.size() > 0, "No items in cart!");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Remove product [{productName}] from cart")
    public CartPage removeProductFromCart(String productName) {
        try {
            Thread.sleep(300);
            List<WebElement> items = driver.findElements(cartItems);

            for (WebElement item : items) {
                String name = item.findElement(cartItemNames).getText().trim();
                if (name.equals(productName)) {
                    WebElement removeBtn = item.findElement(By.cssSelector("button.cart_button"));
                    removeBtn.click();
                    Thread.sleep(300);
                    return this;
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify product [{productName}] is removed from cart")
    public CartPage verifyProductRemoved(String productName) {
        try {
            Thread.sleep(300);
            List<WebElement> items = driver.findElements(cartItemNames);

            for (WebElement item : items) {
                String name = item.getText().trim();
                Assert.assertNotEquals(
                        name,
                        productName,
                        "Product still exists in cart! did not expect [" +
                                productName + "] but found [" + name + "]"
                );
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify cart badge shows count {expectedCount}")
    public CartPage verifyCartBadgeUpdated(int expectedCount) {
        try {
            Thread.sleep(300);
            if (expectedCount == 0) {
                Assert.assertEquals(
                        driver.findElements(cartBadge).size(),
                        0,
                        "Cart badge should not be displayed when cart is empty!"
                );
            } else {
                String badgeText = driver.findElement(cartBadge).getText();
                Assert.assertEquals(
                        Integer.parseInt(badgeText),
                        expectedCount,
                        "Cart badge count mismatch!"
                );
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Click Continue Shopping button")
    public CartPage clickContinueShoppingButton() {
        try {
            Thread.sleep(300);
            Assert.assertTrue(
                    driver.findElement(continueShoppingButton).isDisplayed(),
                    "Continue Shopping button not found!"
            );
            driver.findElement(continueShoppingButton).click();
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify navigation to products page")
    public CartPage verifyNavigationToProductsPage() {
        try {
            Thread.sleep(500);
            String currentUrl = driver.getCurrentUrl();
            Assert.assertTrue(
                    currentUrl.contains("inventory.html") || currentUrl.contains("inventory"),
                    "Not redirected to products page! Current URL: " + currentUrl
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Click Checkout button")
    public CartPage clickCheckoutButton() {
        try {
            Thread.sleep(300);
            Assert.assertTrue(
                    driver.findElement(checkoutButton).isDisplayed(),
                    "Checkout button not found!"
            );
            driver.findElement(checkoutButton).click();
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify navigation to checkout page")
    public CartPage verifyNavigationToCheckoutPage() {
        try {
            Thread.sleep(500);
            String currentUrl = driver.getCurrentUrl();
            Assert.assertTrue(
                    currentUrl.contains("checkout-step-one") || currentUrl.contains("checkout"),
                    "Not redirected to checkout page! Current URL: " + currentUrl
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Get cart item count")
    public int getCartItemCount() {
        return driver.findElements(cartItems).size();
    }

    @Step("Get product names in cart")
    public List<String> getProductNamesInCart() {
        List<String> productNames = new ArrayList<>();
        List<WebElement> items = driver.findElements(cartItemNames);
        for (WebElement item : items) {
            productNames.add(item.getText().trim());
        }
        return productNames;
    }

    @Step("Verify cart is empty")
    public CartPage verifyCartIsEmpty() {
        try {
            Thread.sleep(300);
            int itemCount = driver.findElements(cartItems).size();
            Assert.assertEquals(itemCount, 0, "Cart is not empty!");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }
}
