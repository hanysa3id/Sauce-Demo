package Pages;

import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import java.util.List;

public class ProductPage {
    private final WebDriver driver;
    private static Integer cartItemCount = 0;

    public ProductPage(WebDriver driver) {
        this.driver = driver;
    }

    private final By productsName         = By.cssSelector("[class=\"inventory_item_name \"]");
    private final By productImages        = By.cssSelector(".inventory_item_img img");
    private final By productPrices        = By.cssSelector("[class=\"inventory_item_price\"]");
    private final By productDescriptions  = By.cssSelector("[class=\"inventory_item_desc\"]");
    private final By addToCartButtons     = By.cssSelector("[class*=\"btn_inventory\"]");

    private final By cartBadge            = By.cssSelector("[class=\"shopping_cart_badge\"]");

    private final By sortDropdown         = By.cssSelector("[class=\"product_sort_container\"]");
    private final By sortOptionAZ         = By.xpath("//option[@value='az']");
    private final By sortOptionZA         = By.xpath("//option[@value='za']");
    private final By sortOptionLowHigh    = By.xpath("//option[@value='lohi']");
    private final By sortOptionHighLow    = By.xpath("//option[@value='hilo']");

    private final By inventoryContainer   = By.cssSelector("[class=\"inventory_container\"]");

    @Step("Add product [{productName}] to cart")
    public ProductPage addProductToCart(String productName) {
        try {
            int elements = driver.findElements(productsName).size();
            for (int i = 1; i <= elements; i++) {
                String text = driver.findElement(
                        By.xpath("(//*[@class=\"inventory_item_name \"])[" + i + "]")
                ).getText();
                if (text.equals(productName)) {
                    driver.findElement(
                            By.xpath("(//*[@class=\"btn btn_primary btn_small btn_inventory \"])[" + i + "]")
                    ).click();
                    cartItemCount++;
                    break;
                }
            }
        } catch (Exception ignored) {
        }
        return this;
    }

    @Step("Verify cart badge matches added products count")
    public ProductPage verifyAddedProduct() {
        try {
            Thread.sleep(300);

            if (driver.findElements(cartBadge).isEmpty()) {
                Assert.fail("Cart badge not found – product was not added to cart.");
            }

            String text = driver.findElement(cartBadge).getText();
            Assert.assertEquals(
                    Integer.parseInt(text),
                    cartItemCount,
                    "Product count mismatch! Expected: " + cartItemCount + " | Actual: " + text
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }


    @Step("Verify all product images are displayed with valid src")
    public ProductPage verifyProductsImageIsDisplayed() {
        try {
            Thread.sleep(500);
            List<WebElement> images = driver.findElements(productImages);
            Assert.assertTrue(images.size() > 0, "No product images found!");

            for (WebElement img : images) {
                Assert.assertTrue(img.isDisplayed(), "Product image is not displayed!");
                String src = img.getAttribute("src");
                Assert.assertTrue(src != null && !src.isEmpty(),
                        "Product image src is null or empty!");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify all product prices are displayed and valid")
    public ProductPage verifyProductsPriceIsDisplayed() {
        try {
            Thread.sleep(500);
            List<WebElement> prices = driver.findElements(productPrices);
            Assert.assertTrue(prices.size() > 0, "No product prices found!");

            for (WebElement price : prices) {
                Assert.assertTrue(price.isDisplayed(), "Product price is not displayed!");
                String priceText = price.getText().trim();
                Assert.assertTrue(priceText != null && !priceText.isEmpty(),
                        "Product price is null or empty!");
                Assert.assertTrue(priceText.contains("$"),
                        "Price doesn't contain currency symbol!");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify all product descriptions are displayed")
    public ProductPage verifyProductsDescriptionIsDisplayed() {
        try {
            Thread.sleep(500);
            List<WebElement> descriptions = driver.findElements(productDescriptions);
            Assert.assertTrue(descriptions.size() > 0, "No product descriptions found!");

            for (WebElement description : descriptions) {
                Assert.assertTrue(description.isDisplayed(),
                        "Product description is not displayed!");
                String descriptionText = description.getText().trim();
                Assert.assertTrue(descriptionText != null && !descriptionText.isEmpty(),
                        "Product description is null or empty!");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify sorting of products by Name A-Z")
    public ProductPage verifySortingTC() {
        try {
            Thread.sleep(500);
            List<WebElement> initialProducts = driver.findElements(productsName);
            Assert.assertTrue(initialProducts.size() > 0, "No products found on page");

            WebElement dropdown = driver.findElement(sortDropdown);
            dropdown.click();
            Thread.sleep(300);

            driver.findElement(sortOptionAZ).click();
            Thread.sleep(500);

            List<WebElement> sortedProducts = driver.findElements(productsName);
            for (int i = 0; i < sortedProducts.size() - 1; i++) {
                String current = sortedProducts.get(i).getText().trim();
                String next    = sortedProducts.get(i + 1).getText().trim();
                Assert.assertTrue(
                        current.compareTo(next) <= 0,
                        "Sorting failed! " + current + " > " + next
                );
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify inventory page is loaded")
    public ProductPage verifyInventoryPageLoaded() {
        try {
            Thread.sleep(500);
            Assert.assertTrue(
                    driver.findElements(inventoryContainer).size() > 0,
                    "Inventory page not loaded!"
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Get total number of products on inventory page")
    public int getProductCount() {
        return driver.findElements(productsName).size();
    }

    @Step("Reset cart item counter")
    public ProductPage clearCartCounter() {
        cartItemCount = 0;
        return this;
    }
}
