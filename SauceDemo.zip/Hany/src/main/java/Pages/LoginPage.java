package Pages;

import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import java.time.Duration;

public class LoginPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    private final By emailField         = By.cssSelector("[id=\"user-name\"]");
    private final By passwordField      = By.cssSelector("[id=\"password\"]");
    private final By loginButton        = By.cssSelector("[id=\"login-button\"]");
    private final By errorText          = By.xpath("//h3[@data-test='error']");
    private final By inventoryContainer = By.cssSelector("[class=\"inventory_container\"]");

    @Step("Login with email={email} and password={pass}")
    public LoginPage enterEmailAndPassword(String email, String pass) {
        driver.findElement(emailField).sendKeys(email);
        driver.findElement(passwordField).sendKeys(pass);
        driver.findElement(loginButton).click();
        return this;
    }

    @Step("Click login button with empty fields")
    public LoginPage clickLoginButtonWithEmptyFields() {
        driver.findElement(loginButton).click();
        return this;
    }

    @Step("Verify login success and inventory page is loaded")
    public LoginPage verifyLoginSuccess() {
        try {
            Thread.sleep(500);
            Assert.assertTrue(
                    driver.findElements(inventoryContainer).size() > 0,
                    "Inventory page not loaded - Login failed!"
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify error message contains expected text: {expectedErrorMessage}")
    public LoginPage verifyErrorMessageAppears(String expectedErrorMessage) {
        try {
            Thread.sleep(300);
            Assert.assertTrue(
                    driver.findElements(errorText).size() > 0,
                    "Error message element not found!"
            );
            String actualErrorMessage = driver.findElement(errorText).getText();
            Assert.assertTrue(
                    actualErrorMessage.contains(expectedErrorMessage),
                    "Expected: '" + expectedErrorMessage + "' | Actual: '" + actualErrorMessage + "'"
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify login failed and user stays on login page")
    public LoginPage verifyLoginFailed() {
        try {
            Thread.sleep(300);
            String currentUrl = driver.getCurrentUrl();
            Assert.assertTrue(
                    currentUrl.contains("saucedemo.com/") && !currentUrl.contains("inventory"),
                    "User was redirected to inventory page - Login should have failed!"
            );
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return this;
    }

    @Step("Verify login page elements are displayed")
    public LoginPage verifyLoginPageElements() {
        Assert.assertTrue(
                driver.findElement(emailField).isDisplayed(),
                "Email field not displayed"
        );
        Assert.assertTrue(
                driver.findElement(passwordField).isDisplayed(),
                "Password field not displayed"
        );
        Assert.assertTrue(
                driver.findElement(loginButton).isDisplayed(),
                "Login button not displayed"
        );
        return this;
    }

    @Step("Verify login fields are empty")
    public LoginPage verifyFieldsAreEmpty() {
        String emailValue    = driver.findElement(emailField).getAttribute("value");
        String passwordValue = driver.findElement(passwordField).getAttribute("value");

        Assert.assertTrue(
                emailValue == null || emailValue.isEmpty(),
                "Email field is not empty!"
        );
        Assert.assertTrue(
                passwordValue == null || passwordValue.isEmpty(),
                "Password field is not empty!"
        );
        return this;
    }

    @Step("Clear login fields")
    public LoginPage clearFields() {
        driver.findElement(emailField).clear();
        driver.findElement(passwordField).clear();
        return this;
    }
}
